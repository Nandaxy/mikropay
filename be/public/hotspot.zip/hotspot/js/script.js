document.addEventListener("DOMContentLoaded", function () {
  const footerText = "Beli paket vocher di sini";
  document.getElementById("footText").innerHTML = footerText;

  // Change title based on hostname
  var hostname = window.location.hostname;
  document.getElementById("title").innerHTML = hostname + " > login";

  // Initialize elements
  var infologin = document.getElementById("infologin");
  var username = document.getElementById("username"); 
  var password = document.getElementById("password"); 

  // Default settings
  infologin.innerHTML = "Masukkan Kode Voucher.";
  username.placeholder = "Kode Voucher";
  btnVoucher.classList.add("active");

  // Set password = username
  function setpass() {
    var user = username.value;
    password.value = user;
  }

  // Attach event listener to username input
  username.addEventListener("keyup", setpass);

  // Function to switch to voucher mode
  function voucher() {
    username.addEventListener("keyup", setpass);
    username.placeholder = "Kode Voucher";
    password.type = "hidden";
    infologin.innerHTML = "Masukkan Kode Voucher.";
    btnVoucher.classList.add("active");
    btnMember.classList.remove("active");
  }

  // Function to switch to member mode
  function member() {
    username.removeEventListener("keyup", setpass);
    username.placeholder = "Username";
    password.type = "password";
    infologin.innerHTML = "Masukkan Username dan Password.";
    btnVoucher.classList.remove("active");
    btnMember.classList.add("active");
  }

  // Event listeners for mode buttons
  btnVoucher.addEventListener("click", voucher);
  btnMember.addEventListener("click", member);
});
